package gsmemstats

import (
	"log"
	"testing"
	"time"
)

func Test_LookHeapMemAndGoRun1(t *testing.T) {
	look := NewLookHeapMemAndGoRun(log.Default())
	_ = look
	time.Sleep(time.Second * 10)
}

func Test_LookHeapMemAndGoRun2(t *testing.T) {
	look := NewLookHeapMemAndGoRun_nolog()
	_ = look
	time.Sleep(time.Second * 10)
}
