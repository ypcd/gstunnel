package gsmemstats

import (
	"fmt"
	"log"
	"runtime"
	"time"
)

type LookHeapMem struct {
	memStats *runtime.MemStats
}

func NewLookHeapMem() *LookHeapMem {
	return &LookHeapMem{&runtime.MemStats{}}
}

func (l *LookHeapMem) GetHeapMemStats() string {
	runtime.ReadMemStats(l.memStats)
	return fmt.Sprintf("HeapSys: %d, HeapIdle: %d, HeapReleased: %d, HeapInuse: %d, HeapAlloc: %d, HeapObjects: %d",
		l.memStats.HeapSys, l.memStats.HeapIdle, l.memStats.HeapReleased, l.memStats.HeapInuse, l.memStats.HeapAlloc, l.memStats.HeapObjects)
}

func (l *LookHeapMem) GetHeapMemStatsMiB() string {
	runtime.ReadMemStats(l.memStats)
	return fmt.Sprintf("HeapSys: %dMiB, HeapIdle: %dMiB, HeapReleased: %dMiB, HeapInuse: %dMiB, HeapAlloc: %dMiB, HeapObjects: %d",
		l.memStats.HeapSys/1024/1024, l.memStats.HeapIdle/1024/1024, l.memStats.HeapReleased/1024/1024, l.memStats.HeapInuse/1024/1024, l.memStats.HeapAlloc/1024/1024, l.memStats.HeapObjects)
}

// GC stop-the-world
func (l *LookHeapMem) GetGCInfo() string {
	runtime.ReadMemStats(l.memStats)
	return fmt.Sprintf("GC: GCCPUFraction: %f, PauseTotalNs: %d  %dms, PauseTotalNs: %d, NumGC: %d", l.memStats.GCCPUFraction, l.memStats.PauseTotalNs, l.memStats.PauseTotalNs/1000/1000, l.memStats.PauseNs, l.memStats.NumGC)
}

type LookHeapMemAndGoRun struct {
	LookHeapMem
	inlogger   *log.Logger
	running_go bool
}

func NewLookHeapMemAndGoRun(inlog *log.Logger) *LookHeapMemAndGoRun {
	look := &LookHeapMemAndGoRun{LookHeapMem: LookHeapMem{&runtime.MemStats{}},
		inlogger: inlog,
	}
	look.run()
	return look
}

func NewLookHeapMemAndGoRun_nolog() *LookHeapMemAndGoRun {
	look := &LookHeapMemAndGoRun{LookHeapMem: LookHeapMem{&runtime.MemStats{}}}
	look.run()
	return look
}

func LookHeapMemFunc(look *LookHeapMemAndGoRun) {
	//timer_displayer := timerm.CreateTimer(time.Second * 3)

	memStats := &look.LookHeapMem
	defer fmt.Println(memStats.GetGCInfo())

	time.Sleep(time.Millisecond * 100)
	//logger_test.Println("MemStats:", memStats)
	//	logger_test.Printf("HeapSys: %d, HeapIdle: %d, HeapReleased: %d, HeapInuse: %d, HeapAlloc: %d, HeapObjects: %d\n",
	//		memStats.HeapSys, memStats.HeapIdle, memStats.HeapReleased, memStats.HeapInuse, memStats.HeapAlloc, memStats.HeapObjects)
	for {

		//logger_test.Println("MemStats:", memStats)
		//		logger_test.Printf("HeapSys: %d, HeapIdle: %d, HeapReleased: %d, HeapInuse: %d, HeapAlloc: %d, HeapObjects: %d\n",
		//			memStats.HeapSys, memStats.HeapIdle, memStats.HeapReleased, memStats.HeapInuse, memStats.HeapAlloc, memStats.HeapObjects)
		fmt.Println(memStats.GetHeapMemStatsMiB())
		fmt.Println(memStats.GetGCInfo())
		time.Sleep(time.Second * 3)
	}
}

func LookHeapMemFunc_log(look *LookHeapMemAndGoRun) {
	//timer_displayer := timerm.CreateTimer(time.Second * 3)
	logger := look.inlogger
	memStats := &look.LookHeapMem
	defer logger.Println(memStats.GetGCInfo())

	time.Sleep(time.Millisecond * 100)
	//logger_test.Println("MemStats:", memStats)
	//	logger_test.Printf("HeapSys: %d, HeapIdle: %d, HeapReleased: %d, HeapInuse: %d, HeapAlloc: %d, HeapObjects: %d\n",
	//		memStats.HeapSys, memStats.HeapIdle, memStats.HeapReleased, memStats.HeapInuse, memStats.HeapAlloc, memStats.HeapObjects)
	for {

		//logger_test.Println("MemStats:", memStats)
		//		logger_test.Printf("HeapSys: %d, HeapIdle: %d, HeapReleased: %d, HeapInuse: %d, HeapAlloc: %d, HeapObjects: %d\n",
		//			memStats.HeapSys, memStats.HeapIdle, memStats.HeapReleased, memStats.HeapInuse, memStats.HeapAlloc, memStats.HeapObjects)
		logger.Println(memStats.GetHeapMemStatsMiB())
		logger.Println(memStats.GetGCInfo())
		time.Sleep(time.Second * 3)
	}
}

func (l *LookHeapMemAndGoRun) run() {
	if l.running_go {
		return
	}
	if l.inlogger == nil {
		go LookHeapMemFunc(l)
	} else {
		go LookHeapMemFunc_log(l)
	}
	l.running_go = true
}
